package Test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import main.Service;
import main.Trade;
/* Test cases of trades transmission*/
public class ServiceTest {
	long l=Date.parse("Mon 6 Jan 2023 13:3:00");
	Date day=new Date(l);
	Date  date =  new Date();
	Trade trade1  = new Trade("T1",2,"CP-1","B1",day,date,'N');
	
	long l2=Date.parse("Mon 6 Jan 2000 13:3:00");
	Date day2=new Date(l2);
	Date  date2 =  new Date();
	Trade trade2  = new Trade("T2",2,"CP-2","B2",day2,date2,'N');
	

	Trade trade3  = new Trade("T1",1,"CP-1","B1",day,date,'N');
	
	Trade trade4  = new Trade("T3",3,"CP-3","B2",day,date,'Y');
	
	
	@Test
	public void normalTest() {
		Service.addTrade(trade1);
		Service.getTrade(trade1);
	}
	
	
	@Test
	public void beforeDateTest() {
		Service.addTrade(trade2);
	}
	
	@Test
	public void versonTest() {
		Service.addTrade(trade3);
	}
	
	
	

}
