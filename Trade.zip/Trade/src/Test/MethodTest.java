package Test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import main.Service;
import main.Trade;
import main.Update;

public class MethodTest {


	@Test
	public void test() {
		long l=Date.parse("Thursday 28 April 2023 22:55:00");
		Date day=new Date(l);
		Date  date =  new Date();
		Trade trade1  = new Trade("T1",1,"CP-1","B1",day,date,'N');
		
		Service.addTrade(trade1);
		Service.getTrade(trade1);
		Update.update();
		try {
			Thread.sleep(20000); //sleep
			System.out.print(Service.getTrade(trade1));
			} catch (InterruptedException e) {
		}
	}

}
