package main;

public enum TradeExceptionEnum {
	VERSION_LOW(10001,"version is low"),
	MATURITY_DATE(10002,"maturity date is wrong");
	
	/**
     * error code
     */
    Integer code;
    /**
     * error message
     */
    String msg;

    TradeExceptionEnum(Integer code,String msg){
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

	
}
