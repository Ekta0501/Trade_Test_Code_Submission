package main;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
/*Service class for trade*/
public class Service {
	
	static Map<String,Trade> trades = new HashMap<String,Trade>();

	public static void addTrade(Trade trade){
   
        if(trades.containsKey(trade.getTradeId())&&trades.get(trade.getVersion()).getVersion()>trade.getVersion()) {
        	throw new TradeException(TradeExceptionEnum.VERSION_LOW);       	
        }
        Date date = new Date();
        if(trade.getMaturityDate().before(date)) {
        	throw new TradeException(TradeExceptionEnum.MATURITY_DATE); 
        }
        
        trades.put(trade.getTradeId(), trade);
        
    
    }
	
	public static char getTrade(Trade trade) {
		return trades.get(trade.getTradeId()).getExpired();
	}
	
	public static void  updateTrade() {
		for(String tradeId:trades.keySet()) {
			Date date = new Date();
			Trade t = trades.get(tradeId);
			if(t.getMaturityDate().before(date)) {
				t.setExpired('Y');
				trades.put(tradeId, t);
			}
		}
	}

}
