package main;

public class Update {
/*Thread class for update thread*/
	public static void update(){
	final long timeInterval = 10;
	Runnable runnable = new Runnable() {
		
		@Override
		public void run() {
				while (true) {
					//code run task
					Service.updateTrade();
					try {
					Thread.sleep(timeInterval);
					}catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
		}
	};
	Thread thread = new Thread(runnable);
	thread.start();
	}

}
